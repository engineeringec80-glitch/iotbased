import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { Activity, Thermometer, Droplets, AlertTriangle, LogOut, Sparkles } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export const PatientDashboard: React.FC = () => {
  const { token, logout, user } = useAuth();
  const { socket } = useSocket();
  const navigate = useNavigate();
  const [latestReading, setLatestReading] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    if (!token || !user?.patientId) return;

    const fetchData = async () => {
      try {
        const [latestRes, historyRes, alertsRes] = await Promise.all([
          axios.get(`/api/patients/${user.patientId}/latest`, { headers: { Authorization: `Bearer ${token}` } }),
          axios.get(`/api/patients/${user.patientId}/readings?limit=50`, { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('/api/alerts?limit=5', { headers: { Authorization: `Bearer ${token}` } }),
        ]);
        setLatestReading(latestRes.data);
        setHistory(formatHistory(historyRes.data));
        setAlerts(alertsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [token, user]);

  useEffect(() => {
    if (!socket) return;

    socket.on('new_sensor_data', (data: any) => {
      setLatestReading(data.reading);
      setHistory((prev) => {
        const newHistory = [...prev, formatReading(data.reading)];
        if (newHistory.length > 50) newHistory.shift();
        return newHistory;
      });
      if (data.alerts && data.alerts.length > 0) {
        setAlerts((prev) => [...data.alerts, ...prev].slice(0, 5));
      }
    });

    return () => {
      socket.off('new_sensor_data');
    };
  }, [socket]);

  const formatReading = (reading: any) => ({
    ...reading,
    time: new Date(reading.timestamp).toLocaleTimeString(),
  });

  const formatHistory = (readings: any[]) => readings.map(formatReading);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getAiAnalysis = async () => {
    if (!latestReading) return;
    setAnalyzing(true);
    try {
      const res = await axios.post('/api/ai/analyze', {
        heartRate: latestReading.heartRate,
        spo2: latestReading.spo2,
        temperature: latestReading.temperature,
      }, { headers: { Authorization: `Bearer ${token}` } });
      setAiAnalysis(res.data.analysis);
    } catch (error) {
      console.error('AI Analysis failed', error);
      setAiAnalysis('Failed to generate analysis. Please try again later.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">My Health Dashboard</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">Welcome, {user?.name}</span>
            <button onClick={handleLogout} className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
              <LogOut size={18} /> Logout
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center gap-4 border-l-4 border-red-500">
            <div className="p-3 bg-red-100 rounded-full text-red-500">
              <Activity size={32} />
            </div>
            <div>
              <p className="text-gray-500 text-sm font-semibold uppercase">Heart Rate</p>
              <p className="text-3xl font-bold text-gray-800">{latestReading?.heartRate || '--'} <span className="text-lg font-normal text-gray-500">bpm</span></p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center gap-4 border-l-4 border-blue-500">
            <div className="p-3 bg-blue-100 rounded-full text-blue-500">
              <Droplets size={32} />
            </div>
            <div>
              <p className="text-gray-500 text-sm font-semibold uppercase">SpO2</p>
              <p className="text-3xl font-bold text-gray-800">{latestReading?.spo2 || '--'} <span className="text-lg font-normal text-gray-500">%</span></p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center gap-4 border-l-4 border-orange-500">
            <div className="p-3 bg-orange-100 rounded-full text-orange-500">
              <Thermometer size={32} />
            </div>
            <div>
              <p className="text-gray-500 text-sm font-semibold uppercase">Temperature</p>
              <p className="text-3xl font-bold text-gray-800">{latestReading?.temperature || '--'} <span className="text-lg font-normal text-gray-500">°C</span></p>
            </div>
          </div>
        </div>

        {latestReading && (
          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg shadow-md p-6 mb-8 border border-indigo-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold flex items-center gap-2 text-indigo-800">
                <Sparkles size={20} className="text-indigo-500" /> AI Health Insight
              </h2>
              <button 
                onClick={getAiAnalysis} 
                disabled={analyzing}
                className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50 transition-colors text-sm font-medium"
              >
                {analyzing ? 'Analyzing...' : 'Generate Insight'}
              </button>
            </div>
            {aiAnalysis ? (
              <p className="text-gray-700 leading-relaxed">{aiAnalysis}</p>
            ) : (
              <p className="text-gray-500 italic">Click the button to get an AI-powered analysis of your current vitals.</p>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 border-b pb-2">Heart Rate & SpO2 Trend</h2>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                    <YAxis yAxisId="left" domain={['auto', 'auto']} />
                    <YAxis yAxisId="right" orientation="right" domain={['auto', 'auto']} />
                    <Tooltip />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="heartRate" stroke="#ef4444" strokeWidth={2} dot={false} name="Heart Rate (bpm)" />
                    <Line yAxisId="right" type="monotone" dataKey="spo2" stroke="#3b82f6" strokeWidth={2} dot={false} name="SpO2 (%)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 border-b pb-2">Temperature Trend</h2>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                    <YAxis domain={['auto', 'auto']} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="temperature" stroke="#f97316" strokeWidth={2} dot={false} name="Temperature (°C)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 border-b pb-2 flex items-center gap-2 text-red-600">
                <AlertTriangle size={20} /> My Alerts
              </h2>
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <div key={alert._id} className={`p-3 rounded border-l-4 ${alert.isRead ? 'bg-gray-50 border-gray-300' : 'bg-red-50 border-red-500'}`}>
                    <div className="flex justify-between items-start">
                      <span className="font-semibold text-sm text-gray-800 capitalize">{alert.type} Alert</span>
                      <span className="text-xs text-gray-500">{new Date(alert.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-sm text-gray-700 mt-1">{alert.message}</p>
                  </div>
                ))}
                {alerts.length === 0 && (
                  <p className="text-gray-500 text-center py-4">No recent alerts.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
