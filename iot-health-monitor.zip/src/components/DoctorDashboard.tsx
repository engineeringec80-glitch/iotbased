import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { Activity, Thermometer, Droplets, AlertTriangle, LogOut } from 'lucide-react';

export const DoctorDashboard: React.FC = () => {
  const { token, logout, user } = useAuth();
  const { socket } = useSocket();
  const navigate = useNavigate();
  const [patients, setPatients] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);

  useEffect(() => {
    if (!token) return;

    const fetchData = async () => {
      try {
        const [patientsRes, alertsRes] = await Promise.all([
          axios.get('/api/patients', { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('/api/alerts?limit=10', { headers: { Authorization: `Bearer ${token}` } }),
        ]);
        setPatients(patientsRes.data);
        setAlerts(alertsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [token]);

  useEffect(() => {
    if (!socket) return;

    socket.on('new_sensor_data', (data: any) => {
      if (data.alerts && data.alerts.length > 0) {
        setAlerts((prev) => [...data.alerts, ...prev].slice(0, 10));
      }
    });

    return () => {
      socket.off('new_sensor_data');
    };
  }, [socket]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Doctor Dashboard</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">Welcome, Dr. {user?.name}</span>
            <button onClick={handleLogout} className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
              <LogOut size={18} /> Logout
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 border-b pb-2">My Patients</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-50 text-gray-600">
                      <th className="p-3 border-b">Name</th>
                      <th className="p-3 border-b">Patient ID</th>
                      <th className="p-3 border-b">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {patients.map((p) => (
                      <tr key={p._id} className="hover:bg-gray-50 border-b">
                        <td className="p-3">{p.name}</td>
                        <td className="p-3 font-mono text-sm">{p.patientId}</td>
                        <td className="p-3">
                          <Link to={`/patient/${p.patientId}`} className="text-blue-500 hover:underline">
                            View Details
                          </Link>
                        </td>
                      </tr>
                    ))}
                    {patients.length === 0 && (
                      <tr>
                        <td colSpan={3} className="p-4 text-center text-gray-500">No patients found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 border-b pb-2 flex items-center gap-2 text-red-600">
                <AlertTriangle size={20} /> Recent Alerts
              </h2>
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <div key={alert._id} className={`p-3 rounded border-l-4 ${alert.isRead ? 'bg-gray-50 border-gray-300' : 'bg-red-50 border-red-500'}`}>
                    <div className="flex justify-between items-start">
                      <span className="font-semibold text-sm text-gray-800">Patient: {alert.patientId}</span>
                      <span className="text-xs text-gray-500">{new Date(alert.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-sm text-gray-700 mt-1">{alert.message}</p>
                  </div>
                ))}
                {alerts.length === 0 && (
                  <p className="text-gray-500 text-center py-4">No recent alerts.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
