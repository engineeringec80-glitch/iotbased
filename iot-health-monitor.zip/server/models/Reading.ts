import mongoose from 'mongoose';

const readingSchema = new mongoose.Schema({
  patientId: { type: String, required: true, index: true },
  heartRate: { type: Number, required: true },
  spo2: { type: Number, required: true },
  temperature: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now, index: true },
});

export const Reading = mongoose.model('Reading', readingSchema);
