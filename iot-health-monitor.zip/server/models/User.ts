import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['doctor', 'patient'], required: true },
  patientId: { type: String, unique: true, sparse: true }, // Only for patients
  name: { type: String, required: true },
}, { timestamps: true });

export const User = mongoose.model('User', userSchema);
