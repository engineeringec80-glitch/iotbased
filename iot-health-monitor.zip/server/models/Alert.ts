import mongoose from 'mongoose';

const alertSchema = new mongoose.Schema({
  patientId: { type: String, required: true, index: true },
  type: { type: String, enum: ['heartRate', 'spo2', 'temperature'], required: true },
  value: { type: Number, required: true },
  message: { type: String, required: true },
  timestamp: { type: Date, default: Date.now, index: true },
  isRead: { type: Boolean, default: false },
});

export const Alert = mongoose.model('Alert', alertSchema);
