import express from 'express';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';
import { GoogleGenAI } from '@google/genai';

const router = express.Router();

router.post('/analyze', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { heartRate, spo2, temperature } = req.body;

    if (!heartRate || !spo2 || !temperature) {
      return res.status(400).json({ message: 'Missing reading data' });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    const prompt = `As a medical AI assistant, provide a brief, easy-to-understand analysis (max 3 sentences) of the following patient vitals:
    - Heart Rate: ${heartRate} bpm
    - SpO2: ${spo2}%
    - Body Temperature: ${temperature}°C
    
    Note: Normal HR is 60-100 bpm, normal SpO2 is 95-100%, normal temp is 36.1-37.2°C.
    If anything is abnormal, mention it clearly but keep a calm tone.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-preview',
      contents: prompt,
    });

    res.json({ analysis: response.text });
  } catch (error) {
    console.error('AI Analysis error:', error);
    res.status(500).json({ message: 'Failed to generate analysis' });
  }
});

export default router;
