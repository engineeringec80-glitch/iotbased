import express from 'express';
import { Reading } from '../models/Reading.js';
import { Alert } from '../models/Alert.js';
import { User } from '../models/User.js';

const router = express.Router();

// Thresholds
const THRESHOLDS = {
  heartRate: { min: 60, max: 100 },
  spo2: { min: 95 },
  temperature: { min: 35, max: 38 },
};

// NodeMCU sends data here
router.post('/', async (req, res) => {
  try {
    const { patientId, heartRate, spo2, temperature, timestamp } = req.body;

    if (!patientId || heartRate === undefined || spo2 === undefined || temperature === undefined) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Check if patient exists
    const patient = await User.findOne({ patientId, role: 'patient' });
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    const readingTime = timestamp ? new Date(timestamp) : new Date();

    // Save reading
    const reading = new Reading({
      patientId,
      heartRate,
      spo2,
      temperature,
      timestamp: readingTime,
    });
    await reading.save();

    // Check for alerts
    const alerts = [];
    if (heartRate < THRESHOLDS.heartRate.min || heartRate > THRESHOLDS.heartRate.max) {
      alerts.push({
        patientId,
        type: 'heartRate',
        value: heartRate,
        message: `Abnormal Heart Rate: ${heartRate} bpm`,
        timestamp: readingTime,
      });
    }
    if (spo2 < THRESHOLDS.spo2.min) {
      alerts.push({
        patientId,
        type: 'spo2',
        value: spo2,
        message: `Low SpO2: ${spo2}%`,
        timestamp: readingTime,
      });
    }
    if (temperature < THRESHOLDS.temperature.min || temperature > THRESHOLDS.temperature.max) {
      alerts.push({
        patientId,
        type: 'temperature',
        value: temperature,
        message: `Abnormal Temperature: ${temperature}°C`,
        timestamp: readingTime,
      });
    }

    let savedAlerts = [];
    if (alerts.length > 0) {
      savedAlerts = await Alert.insertMany(alerts);
    }

    // Broadcast via Socket.io
    const io = req.app.get('io');
    if (io) {
      const payload = {
        reading,
        alerts: savedAlerts,
      };
      // Send to patient's room
      io.to(`patient_${patientId}`).emit('new_sensor_data', payload);
      // Send to all doctors
      io.to('doctors').emit('new_sensor_data', payload);
    }

    res.status(201).json({ message: 'Data received', reading, alerts: savedAlerts });
  } catch (error) {
    console.error('Sensor data error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
