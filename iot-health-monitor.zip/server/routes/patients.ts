import express from 'express';
import { authenticateToken, requireRole, AuthRequest } from '../middleware/auth.js';
import { User } from '../models/User.js';
import { Reading } from '../models/Reading.js';
import { Alert } from '../models/Alert.js';

const router = express.Router();

// Get all patients (Doctor only)
router.get('/', authenticateToken, requireRole('doctor'), async (req: AuthRequest, res) => {
  try {
    const patients = await User.find({ role: 'patient' }).select('-password');
    res.json(patients);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get patient details (Doctor or the patient themselves)
router.get('/:id', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const patientId = req.params.id;

    if (req.user?.role === 'patient' && req.user?.patientId !== patientId) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const patient = await User.findOne({ patientId, role: 'patient' }).select('-password');
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    res.json(patient);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get latest reading for a patient
router.get('/:id/latest', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const patientId = req.params.id;

    if (req.user?.role === 'patient' && req.user?.patientId !== patientId) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const reading = await Reading.findOne({ patientId }).sort({ timestamp: -1 });
    res.json(reading || null);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get historical readings for a patient
router.get('/:id/readings', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const patientId = req.params.id;
    const limit = parseInt(req.query.limit as string) || 100;

    if (req.user?.role === 'patient' && req.user?.patientId !== patientId) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const readings = await Reading.find({ patientId }).sort({ timestamp: -1 }).limit(limit);
    res.json(readings.reverse()); // Return chronological order
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
