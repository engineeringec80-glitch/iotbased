import express from 'express';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';
import { Alert } from '../models/Alert.js';

const router = express.Router();

// Get alerts for logged-in user
router.get('/', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    
    if (req.user?.role === 'doctor') {
      // Doctor sees all alerts
      const alerts = await Alert.find().sort({ timestamp: -1 }).limit(limit);
      return res.json(alerts);
    } else if (req.user?.role === 'patient') {
      // Patient sees only their alerts
      const alerts = await Alert.find({ patientId: req.user.patientId }).sort({ timestamp: -1 }).limit(limit);
      return res.json(alerts);
    }

    res.status(403).json({ message: 'Forbidden' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Mark alert as read
router.patch('/:id/read', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const alertId = req.params.id;
    const alert = await Alert.findById(alertId);

    if (!alert) {
      return res.status(404).json({ message: 'Alert not found' });
    }

    if (req.user?.role === 'patient' && req.user.patientId !== alert.patientId) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    alert.isRead = true;
    await alert.save();

    res.json(alert);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
